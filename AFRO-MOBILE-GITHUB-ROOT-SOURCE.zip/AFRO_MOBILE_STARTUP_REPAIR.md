# AFRO MOBILE startup repair notes

## Changes in this repair pass
- Added a 2.5-second fallback around the saved launcher-mode lookup so a stalled AsyncStorage read cannot hold the native splash screen indefinitely.
- Added an 8-second timeout and a bundled AFRO CITY RP distribution fallback when the remote distribution endpoint is missing, invalid, or unavailable.
- Made cache inspection optional during startup; filesystem/cache errors no longer route the user away from the launcher.
- Moved permission, settings, news, donation, and push-notification initialization off the critical startup path.
- Added request timeouts for optional news and donation APIs.
- Corrected the Android MainActivity BuildConfig import so it uses the app's generated BuildConfig.
- Removed a malformed Android permission declaration. WAKE_LOCK and RECORD_AUDIO remain declared separately.

## Important limitations
- The bundled fallback lets the launcher UI start and shows the AFRO CITY RP server entry. It does not provide game cache files, a cache CDN, launcher update hosting, news, or donation services.
- A real APK build and on-device test are still required. This environment does not contain installed Node dependencies or a configured Android SDK/NDK toolchain.
- The Android native GTA/SA-MP libraries supplied in this project are armeabi-v7a only. Do not advertise this build as 64-bit compatible without matching 64-bit native libraries.
