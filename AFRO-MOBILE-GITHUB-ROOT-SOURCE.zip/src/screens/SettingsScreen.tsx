import { APP_VERSION } from '@env';
import React, { useState } from 'react';
import { ActivityIndicator, ScrollView, Text, View } from 'react-native';
import { setAlertUpdatingMode } from '../actions/alertActions';
import {
  setSettingFps,
  setSettingFpsCounter,
  setSettingGraphic,
  setSettingKeyboard,
  setSettingPageSize,
  setUserNameSetting,
} from '../actions/settingsActions';
import { MainContainer, RangeLauncher, SwitchLauncher } from '../components';
import { AlertUpdateMode } from '../components/AlertScreen/AlertUpdateMode';
import { InputLauncher } from '../components/InputLauncher/InputLauncher';
import { useAppDispatch } from '../hooks/useAppDispatch';
import { useAppSelector } from '../hooks/useAppSelector';
import { selectModeType, selectSettings } from '../selectors/settingSelectors';
import { nameFileRecursion } from '../thunks/loaderThunks';
import {
  fetchFPSSetting,
  fetchFpsSetting,
  fetchGraphicSetting,
  fetchKeyboardSetting,
  fetchModeSetting,
  fetchPageSizeSetting,
  fetchUserNameSetting,
} from '../thunks/settingsThunks';
import * as Icons from './../assets/svg';
import { styles } from './../styles/SettingsStyle';

export const SettingsScreen = React.memo(() => {
  const [isLoading, setIsLoading] = useState(false);

  const settings = useAppSelector(selectSettings);
  const settingMode = useAppSelector(selectModeType);
  const dispatch = useAppDispatch();

  const onEndEditingUserName = React.useCallback((value: string) => {
    dispatch(fetchUserNameSetting(value));
    dispatch(setUserNameSetting({ userName: value }));
  }, []);

  const onValueChangeFps = React.useCallback((e: number) => {
    dispatch(setSettingFps({ fpsLimit: Math.floor(e) }));
  }, []);

  const onSlidingCompleteFps = React.useCallback((e: number) => {
    dispatch(fetchFpsSetting(Math.floor(e)));
  }, []);

  const onValueChangePageSize = React.useCallback((e: number) => {
    dispatch(setSettingPageSize({ pageSize: Math.floor(e) }));
  }, []);

  const onSlidingCompletePageSize = React.useCallback((e: number) => {
    dispatch(fetchPageSizeSetting(Math.floor(e)));
  }, []);

  const onValueChangeSnow = React.useCallback(async (value: boolean) => {
    setIsLoading(true);

    try {
      const res = await dispatch(nameFileRecursion());
      if (res) {
        dispatch(setAlertUpdatingMode(true));
      }
    } catch (e) {}
    dispatch(fetchModeSetting(value ? 1 : 0));

    setIsLoading(false);
  }, []);

  const onValueChangeGraphic = React.useCallback((value: boolean) => {
    dispatch(setSettingGraphic({ graphic: value ? 1 : 0 }));
    dispatch(fetchGraphicSetting(value ? 1 : 0));
  }, []);

  const onValueChangeFPS = React.useCallback((value: boolean) => {
    dispatch(setSettingFpsCounter({ fpscounter: value ? 1 : 0 }));
    dispatch(fetchFPSSetting(value));
  }, []);

  const onValueChangeKeyboard = React.useCallback((value: boolean) => {
    dispatch(setSettingKeyboard({ androidKeyboard: value ? 1 : 0 }));
    dispatch(fetchKeyboardSetting(value));
  }, []);

  return (
    <>
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={'#228dff'} />
        </View>
      )}
      <MainContainer>
        <View style={styles.settingWrapper}>
          <View style={styles.setting}>
            <Text style={styles.title}>Settings</Text>
          </View>
          <ScrollView>
            <View style={styles.body}>
              <View>
                <InputLauncher
                  Icon={Icons.UnionSvg}
                  title={'Your Nickname'}
                  value={settings.userName}
                  onChangeText={onEndEditingUserName}
                  placeholder={'Example: Alex_Smith'}
                />
              </View>
              <View style={styles.switch}>
                <SwitchLauncher
                  onValueChange={onValueChangeSnow}
                  value={+settingMode}
                  title={'Winter Map'}
                />
                <SwitchLauncher
                  onValueChange={onValueChangeGraphic}
                  value={+settings.graphic}
                  title={'Enhanced Graphics'}
                />
                <SwitchLauncher
                  onValueChange={onValueChangeFPS}
                  value={+settings.fpscounter}
                  title={'FPS Counter'}
                />
                <SwitchLauncher
                  onValueChange={onValueChangeKeyboard}
                  value={+settings.androidKeyboard}
                  title={'Android Keyboard'}
                />
              </View>
              <View style={styles.range}>
                <RangeLauncher
                  title={'In-game FPS'}
                  minimumValue={20}
                  maximumValue={60}
                  range={settings.fpsLimit}
                  onValueChange={onValueChangeFps}
                  onSlidingComplete={onSlidingCompleteFps}
                />
                <RangeLauncher
                  title={'Chat Lines'}
                  minimumValue={5}
                  maximumValue={20}
                  range={settings.pageSize}
                  onValueChange={onValueChangePageSize}
                  onSlidingComplete={onSlidingCompletePageSize}
                />
              </View>
            </View>
          </ScrollView>
          <Text style={styles.version}>Version {APP_VERSION}</Text>
        </View>
      </MainContainer>
      <AlertUpdateMode />
    </>
  );
});
