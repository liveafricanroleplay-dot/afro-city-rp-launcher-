import RNGpuInfo from 'react-native-gpu-info';
import { setGPU, setInitial } from '../actions/appActions';
import { AppThunk } from '../store/store';
import { fetchArticles } from './articleThunks';
import { fetchDistribution } from './distributionThunks';
import { fetchDonates } from './donateThunks';
import { appRegisterDeviceForRemoteMessages } from './notificationThunks';
import { fetchPermisions } from './permisionThunks';
import { fetchInitialSettings } from './settingsThunks';

export const fetchInitialApp = (): AppThunk => async dispatch => {
  try {
    try {
      const glRenderer = RNGpuInfo.getGlRenderer();
      dispatch(setGPU(glRenderer));
    } catch (error) {
      console.warn('GPU information unavailable:', error);
    }

    // Permissions and optional content are loaded in the background so a
    // permission dialog or offline news/donation API cannot freeze startup.
    void dispatch(fetchPermisions());
    void dispatch(fetchInitialSettings());
    await dispatch(fetchDistribution());

    void dispatch(fetchArticles());
    void dispatch(fetchDonates());
    void dispatch(appRegisterDeviceForRemoteMessages()).catch(error => {
      console.warn('Push notifications unavailable:', error);
    });
  } catch (error) {
    console.warn('AFRO MOBILE startup continued with limited services:', error);
  } finally {
    // Always release the initiation screen, including when a native module or
    // remote service fails.
    dispatch(setInitial({ initial: true }));
  }
};
