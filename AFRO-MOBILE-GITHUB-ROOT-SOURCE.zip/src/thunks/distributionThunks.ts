import { setDistribution } from '../actions/distributionActions';
import { DistributionService } from '../services/distribution.service';
import { AppThunk } from '../store/store';
import { compareFileRecursion } from './loaderThunks';

export const fetchDistribution = (): AppThunk => async (dispatch, state) => {
  const { cache: caches, ...res } = await DistributionService.get();
  dispatch(setDistribution(res));

  // Cache inspection is optional at startup. A filesystem issue should not
  // prevent the launcher UI from opening.
  if (!state().settings.skip && caches.length > 0) {
    try {
      await dispatch(compareFileRecursion({ caches }));
    } catch (error) {
      console.warn('AFRO cache check skipped:', error);
    }
  }
};
