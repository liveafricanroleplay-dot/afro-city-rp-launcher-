import { URL_DISTRIBUTION } from '@env';
import axios from 'axios';
import { CacheType } from '../actions/loaderActions';

const fallbackDistribution: DistributionResponseType = {
  cdnLauncher: '',
  cdnCache: '',
  cacheMode: [],
  rss: '',
  versionHash: 'afro-mobile-offline-fallback',
  packageName: 'com.touch.mobile.dark',
  projectName: 'AFRO MOBILE',
  servers: [
    {
      id: 1,
      show: true,
      version: '1.0',
      icon: '',
      events: [],
      slot: 1000,
      bonus: false,
      name: 'AFRO CITY RP',
      description: 'Official AFRO CITY RP SA-MP server',
      address: '142.132.203.47:14585',
      sampVersion: '0.3.7',
    },
  ],
  launcher: {
    appVersion: '1.0.0',
    name: 'afro-mobile.apk',
    hash: '',
    bytes: 0,
    size: 'Not published',
  },
  filesContinue: [],
  cache: [],
};

export const DistributionService = {
  async get(): Promise<DistributionResponseType> {
    // Missing or unreachable distribution services must not trap users on
    // the native splash screen. Start with the bundled AFRO server entry.
    if (!URL_DISTRIBUTION || !/^https?:\\/\\//i.test(URL_DISTRIBUTION)) {
      return fallbackDistribution;
    }

    try {
      const response = await axios.get<DistributionResponseType>(
        URL_DISTRIBUTION,
        { timeout: 8000 },
      );
      const data = response.data;
      if (!data || !Array.isArray(data.servers) || !data.launcher) {
        return fallbackDistribution;
      }
      return data;
    } catch (error) {
      console.warn('AFRO distribution unavailable; using bundled settings.', error);
      return fallbackDistribution;
    }
  },
};

type DistributionResponseType = DistributionResponse & {
  cache: CacheType[];
};

export type DistributionResponse = {
  cdnLauncher: string;
  cdnCache: string;
  cacheMode: CacheType[];
  rss: string;
  versionHash: string;
  packageName: string;
  projectName: string;
  servers: ServerType[];
  launcher: LauncherType;
  filesContinue: FileContinueType;
};

type FileContinueType = string[];

type LauncherType = {
  appVersion: string;
  name: string;
  hash: string;
  bytes: number;
  size: string;
};

type EventType = {
  title: string;
  style: 'red' | 'blue';
};

export type ServerType = {
  id: number;
  show: boolean;
  version: string;
  icon: string;
  events: EventType[];
  slot: number;
  bonus: boolean;
  name: string;
  description: string;
  address: string;
  sampVersion: string;
};
