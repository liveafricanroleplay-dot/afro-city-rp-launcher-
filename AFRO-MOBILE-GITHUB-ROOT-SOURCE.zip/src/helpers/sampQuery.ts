import { Buffer } from 'buffer';
import dgram from 'react-native-udp';

type QueryType = {
  host: string;
  port?: number;
  timeout?: number;
  opcode?: 'i' | 'r' | 'd';
};

export type QueryTypeResponse = {
  passworded: string;
  players: number;
  maxplayers: number;
  hostname: string;
  gamemode: string;
  mapname: string;
};

export const getServerQuery = async ({
  host,
  port = 7777,
  opcode = 'i',
  timeout = 5000,
}: QueryType): Promise<QueryTypeResponse> => {
  const octets = host.split('.').map(value => Number(value));
  if (octets.length !== 4 || octets.some(value => !Number.isInteger(value) || value < 0 || value > 255)) {
    throw new Error(`Invalid IPv4 address: ${host}`);
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`Invalid server port: ${port}`);
  }

  return new Promise((resolve, reject) => {
    const socket = dgram.createSocket({ type: 'udp4' });
    const packet = Buffer.alloc(11);
    packet.write('SAMP', 0, 'ascii');
    octets.forEach((octet, index) => { packet[4 + index] = octet; });
    packet[8] = port & 0xff;
    packet[9] = (port >> 8) & 0xff;
    packet[10] = opcode.charCodeAt(0);

    let settled = false;
    const finish = (error?: Error, result?: QueryTypeResponse) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { socket.close(); } catch (_) {}
      if (error) reject(error);
      else if (result) resolve(result);
    };
    const timer = setTimeout(() => finish(new Error('SA-MP server query timed out')), timeout);

    socket.on('error', (error: Error) => finish(error));
    socket.on('message', (message: Buffer) => {
      try {
        if (message.length < 11 || message.slice(0, 4).toString('ascii') !== 'SAMP') {
          throw new Error('Invalid SA-MP query response');
        }
        const response = message.slice(11);
        if (opcode !== 'i' || response.length < 11) {
          throw new Error('Unsupported or incomplete SA-MP query response');
        }
        let offset = 0;
        const passworded = response.readUInt8(offset++).toString();
        const players = response.readUInt16LE(offset); offset += 2;
        const maxplayers = response.readUInt16LE(offset); offset += 2;
        const readString = () => {
          if (offset + 4 > response.length) throw new Error('Incomplete SA-MP string length');
          const length = response.readUInt32LE(offset); offset += 4;
          if (length > response.length - offset) throw new Error('Incomplete SA-MP string');
          const value = decode(response.slice(offset, offset + length));
          offset += length;
          return value;
        };
        const hostname = readString();
        const gamemode = readString();
        const mapname = readString();
        finish(undefined, { passworded, players, maxplayers, hostname, gamemode, mapname });
      } catch (error) {
        finish(error instanceof Error ? error : new Error('Could not parse SA-MP response'));
      }
    });

    socket.bind(() => {
      socket.send(packet, 0, packet.length, port, host, (error?: Error | null) => {
        if (error) finish(error);
      });
    });
  });
};

const decode = (buffer: Buffer): string => {
  let charset = '';
  for (let i = 0; i < 128; i++) charset += String.fromCharCode(i);
  charset +=
    '€�‚ƒ„…†‡�‰�‹�����‘’“”•–—�™�›���� ΅Ά£¤¥¦§¨©�«¬­®―°±²³΄µ¶·ΈΉΊ»Ό½ΎΏΐΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡ�ΣΤΥΦΧΨΩΪΫάέήίΰαβγδεζηθικλμνξοπρςστυφχψωϊϋόύώ�';
  const charsetBuffer = Buffer.from(charset, 'ucs2');
  const decodeBuffer = Buffer.alloc(buffer.length * 2);
  for (let i = 0; i < buffer.length; i++) {
    decodeBuffer[i * 2] = charsetBuffer[buffer[i] * 2];
    decodeBuffer[i * 2 + 1] = charsetBuffer[buffer[i] * 2 + 1];
  }
  return decodeBuffer.toString('ucs2');
};
